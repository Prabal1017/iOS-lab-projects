//
//  Food.swift
//  MealTracker
//
//  Created by Doan Le Thieu on 3/24/18.
//  Copyright © 2018 Doan Le Thieu. All rights reserved.
//

import Foundation

struct Food {
    var name: String
    var description: String
}
